# voter_portel
its a demo software to enhance my skills 

link : https://voter-portal.onrender.com
